from torchprof.profile import Profile

name = "torchprof"

__all__ = ["Profile"]
__version__ = "1.3.3"

